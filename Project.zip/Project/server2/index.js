const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");

const pg = require("pg");
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Sequelize, DataTypes } = require("sequelize");

const db = new pg.Pool({
  user: "postgres",
  host: "34.71.87.187",
  database: "airegulation_dev",
  password: "India@5555",
  port: 5432,
});
const JWT_SECRET = "Hjkl2345Olkj0987Ooiuyhjnb0987Nbvcty12fgh675redf23";

/***USER AUTH****** */
const sequelize = new Sequelize("airegulation_dev", "postgres", "India@5555", {
  host: "34.71.87.187",
  dialect: "postgres",
});

const Customer = sequelize.define(
  "Customer",
  {
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: "customer", // Use the existing table name
    timestamps: false, // Disable timestamps if they are not present in the existing table
  }
);

// Sync database (no need to sync in this case since the table already exists)
// sequelize.sync();

// Signup route
app.post("/signup", async (req, res) => {
  const { email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newCustomer = await Customer.create({
      email,
      password: hashedPassword,
    });
    res.status(201).send("Customer created");
  } catch (err) {
    console.error(err);
    res.status(400).send("Error creating customer");
  }
});

// Login route
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const customer = await Customer.findOne({ where: { email } });
    if (!customer) {
      return res.status(400).send("Customer not found");
    }
    const isMatch = await bcrypt.compare(password, customer.password);
    if (!isMatch) {
      return res.status(400).send("Invalid credentials");
    }
    const token = jwt.sign({ customerId: customer.id }, JWT_SECRET, {
      expiresIn: "1h",
    });
    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(400).send("Error logging in");
  }
});

// Protected route example
app.get("/protected", (req, res) => {
  const token = req.headers["authorization"];
  if (!token) {
    return res.status(401).send("Access denied");
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    res.send("Protected data");
  } catch (err) {
    res.status(401).send("Invalid token");
  }
});