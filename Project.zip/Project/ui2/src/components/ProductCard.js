import React from 'react';


const ProductCard = ({ product }) => {
  return (
    <div className="border rounded-md p-4">
      <img src={product.image} alt={product.name} className="w-full h-auto" />
      <div className="mt-2">
        <div className="font-bold">{product.name}</div>
        <div className="text-gray-500">${product.price}</div>
        <button className="bg-blue-500 text-white px-4 py-2 mt-2 rounded-md">Buy</button>
      </div>
    </div>
  );
};

export default ProductCard;
