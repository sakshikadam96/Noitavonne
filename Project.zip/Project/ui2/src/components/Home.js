// Home.js

import React from 'react';
import NavBar from './NavBar'; // Import NavBar component
import ContentSection from './ContentSection';
import ProductGrid from './ProductGrid';
import Footer from './Footer';
import Top from '../assest/top.jpg';
import Top2 from '../assest/top2.jpg';
import hii from '../assest/hiii.jpg';
import Dress from '../assest/dress.jpg';
import { filterProducts } from './ProductUtils'; // Import filterProducts function

const Home = () => {
  // Example products data
  const products = [
    { id: 4, name: 'Dress', image: Dress, price: 80 },
    { id: 7, name: 'Dress', image: Top, price: 40 },
    { id: 8, name: 'Dress', image: Top2, price: 50 },
    { id: 9, name: 'Dress', image: hii, price: 60 },
  ];

  // Example handleSearchChange function
  const handleSearchChange = (event) => {
    const searchTerm = event.target.value;
    const filteredProducts = filterProducts(products, searchTerm); // Ensure filterProducts is called correctly
    // Handle filtered products
  };

  return (
    <div>
      <h1 className="text-2xl font-bold">Welcome to our E-Commerce Website!</h1>
      <ContentSection />
      <div>
        <h2 className="text-2xl font-bold mb-4">Products</h2>
        <ProductGrid products={products} />
      </div>
      {/* Pass filterProducts as a prop */}
      <Footer />
    </div>
  );
};

export default Home;
