import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-200 text-black py-4 text-center">
      <p>&copy; 2024 Your E-Commerce Website. All rights reserved.</p>
    </footer>
  );
};

export default Footer;