import React from 'react';
import logo from '../assest/first.jpg';
import glass from "../assest/glasses-415256_640.jpg";

const ContentSection = () => {
  return (
    <div className="flex mt-8 bg-gray-200 p-4 rounded-lg">
      <div className="w-1/2">
        <img src={logo} alt="Example" className="w-full h-auto" style={{ maxWidth: '80%', height: 'auto' }} />
      </div>
      <div 
        className="w-1/2 px-8 rounded-lg p-6" 
        style={{ 
          backgroundImage: `url(${glass})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
        }}
      >
        <h2 className="text-5xl font-bold mb-4">Best Products</h2>
        <p>
          <strong>
            Discover a wide variety of products tailored to meet your needs. 
          </strong>
        </p>
      </div>
    </div>
  );
};

export default ContentSection;

    
    
    
    
    
    
    
    
    