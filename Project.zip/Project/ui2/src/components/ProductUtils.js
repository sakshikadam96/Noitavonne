export const filterProducts = (products, searchTerm) => {
    // Filtering logic here
    // Filtering by name
    const filteredByName = products.filter(product => product.name.toLowerCase().includes(searchTerm.toLowerCase()));
  
    // Filtering by price (assuming searchTerm is a number)
    const filteredByPrice = products.filter(product => product.price <= parseFloat(searchTerm));
  
    // Merging the filtered results directly without storing them in a variable
    const uniqueProducts = [...filteredByName, ...filteredByPrice].filter((product, index, self) => self.indexOf(product) === index);
  
    return uniqueProducts;
  };