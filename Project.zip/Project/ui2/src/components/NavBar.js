import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import logo from '../assest/logo.svg'; // Ensure this path is correct

const NavBar = ({ products, filterProducts, props }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
    const searchTerm = event.target.value;
    props.filterProducts(searchTerm); // Use the correct prop name here
  };

  return (
    <nav className="bg-blue-500 p-4">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <img src={logo} alt="Logo" className="h-8 w-8 mr-2" />
          <div className="text-white text-lg font-bold">E-Commerce</div>
        </div>
       
        <div className="flex justify-center md:justify-end space-x-4">
          <Link to="/" className="text-white">Home</Link>
          <Link to="/products" className="text-white">Products</Link>
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="px-4 py-2 rounded-md"
          />
          
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
