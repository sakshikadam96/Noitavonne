import React from 'react';

const ProductGrid = ({ products }) => {
  return (
    <div className="grid grid-cols-4 gap-4">
      {products.map((product) => (
        <div key={product.id} className="relative">
          <img
            src={product.image}
            alt={product.name}
            className="object-cover w-full h-auto rounded-lg"
          />
          {/* Add hover effect */}
          <div className="absolute inset-0 bg-black bg-opacity-50 rounded-lg opacity-0 hover:opacity-100 transition-opacity duration-300">
            <div className="flex flex-col justify-center items-center h-full">
              <button className="bg-white text-black px-4 py-2 rounded-lg mb-2">Add to Cart</button>
              <p className="text-white">{`$${product.price}`}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductGrid;
