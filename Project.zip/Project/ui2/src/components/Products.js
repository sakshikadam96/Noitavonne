import React from 'react';
import ProductGrid from './ProductGrid';
import tshirtImage from '../assest/first.jpg';
import Second from '../assest/second.jpg';
import Dress2 from '../assest/dress2.jpg';
import Dress from '../assest/dress.jpg';
import okk from '../assest/okk.jpg';
import Top from '../assest/top.jpg';
import Top2 from '../assest/top2.jpg';
import hii from '../assest/hiii.jpg';
import hiii from '../assest/hiiii.jpg';
import black from '../assest/black.jpg';
import NavBar from './NavBar'; // Import NavBar component



const Products = () => {
  const filterProducts = (priceRange) => {
    // Define your filtering logic here
  };
  
  
  const products = [
    { id: 2, name: 'Jeans', image: Second, price: 30 },
    { id: 3, name: 'Sneakers', image: black, price: 50 },
    { id: 5, name: 'Dress', image: Dress2, price: 40 },
    { id: 6, name: 'Dress', image: okk, price: 80 },
    { id: 4, name: 'Dress', image: Dress, price: 80 },
    { id: 1, name: 'T-Shirt', image: tshirtImage, price: 20 },
    { id: 7, name: 'Dress', image: Top, price: 40 },
    { id: 8, name: 'Dress', image: Top2, price: 50 },
    { id: 9, name: 'Dress', image: hii, price: 60 },
    { id: 10, name: 'Dress', image: hiii, price: 30 },
    // Add more products as needed
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Products</h2>
      <ProductGrid products={products} />
      {/* Pagination component or links */}

    </div>
  );
};
export default Products;